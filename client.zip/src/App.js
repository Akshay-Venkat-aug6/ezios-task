import React, { useEffect } from 'react'
import Router from "./router";
import axios from 'axios';

function App() {
  useEffect(() => {
    axios.get('http://localhost:3001/api/v1/session')
      .then((response) => {
        console.log(response)
      })
  });

  return (
    <Router />
  );
}

export default App;
