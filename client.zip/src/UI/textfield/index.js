import React from 'react';
import { TextField  } from '@material-ui/core';

const InputField = ({ label, name, handlechange, classname, type, value }) => {
  return (
    <TextField
      label = { label }
      name = { name }
      onChange = { handlechange }
      type = { type }
      className = { classname }
      value = { value }
    />
  )
};

export default InputField