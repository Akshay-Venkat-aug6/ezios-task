import React from 'react';
import { TextField  } from '@material-ui/core';

const InputField = ({ label, name, handlechange, classname, type }) => {
  return (
    <TextField
      label = { label }
      name = { name }
      onChange = { handlechange }
      type = { type }
      className = { classname }
    />
  )
};

export default InputField