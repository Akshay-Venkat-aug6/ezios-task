import axios from 'axios';

const baseUrl = 'http://localhost:3001/api';

export const userLogin = (userData) => {
  return axios.post(`${baseUrl}/v1/login`, userData);
};

export const getHome = () => {
  return axios.get(`${baseUrl}/v1/`);
}