import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { GetHome } from '../store/user/user.action';

const HomePage = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    dispatch(GetHome(history))
  }, []);

  return (
    <div>
      Hai
    </div>
  )
};

export default HomePage