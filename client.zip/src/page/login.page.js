import React, { useState, useEffect } from 'react';
import { Checkbox, FormControlLabel, Button   } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { UserLogin } from '../store/user/user.action';
import InputField from '../UI/textfield';
import { makeStyles } from '@material-ui/styles';
import { useCookies } from 'react-cookie';
import Cookies from 'universal-cookie';

const LoginPage = () => {
  const cookies = new Cookies();
  const _styles = useStyles();
  const [ input, setInput ] = useState({
    username: '',
    password: ''
  });
  const [ rememberme, setRememberMe ] = useState(false);
  const [ rememberCookie, setRememberCookie] = useCookies(['remember']);
  const [ credentialsCookie, setCredentialsCookie] = useCookies(['userData']);

  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    setRememberMe(cookies.get('remember') === "true");
    if ( cookies.get('remember') === "true" ) {
      setInput( cookies.get('userData') )
    }
  }, [ cookies.get('remember') ])

  const handleChange = (event) => {
    setRememberMe(event.target.checked)
    
  };

  const handleForm = (event) => {
    setInput({...input, [event.target.name]: event.target.value})
  };

  const handleSignin = () => {
    setRememberCookie('remember', rememberme)
    if ( cookies.get('remember') === "true") {
      setCredentialsCookie('userData', input)
    }
    else (
      setCredentialsCookie('userData', null)
    )
    dispatch(UserLogin(input, history))
  }

  return (
    <div className = { _styles.container }>
      <div className = { _styles.loginBox }>
        <h2 className = { _styles.title }> Login </h2>
        <InputField
          label = "username"
          name = "username"
          handlechange = { handleForm }
          classname = { _styles.input }
          value = { input.username }
        />
        <InputField
          label = "password"
          name = "password"
          type = "password"
          handlechange = { handleForm }
          classname = { _styles.input }
          value = { input.password }
        />
        <FormControlLabel
          control={<Checkbox checked={rememberme} onChange = { handleChange } name="remember me" />}
          label="Remember Me"
          className = { _styles.input }
        />
        <Button variant="contained" color="primary" className = { _styles.input } onClick = { handleSignin }>
          Submit
        </Button>
      </div>
      
    </div>
  )
};

const useStyles = makeStyles({
  container: {
    // height: '100vh',
    margin: 30,
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    // backgroundColor: 'red'
  },
  loginBox: {
    marginTop: '10%',
    // backgroundColor: 'red',
    width: '250px'
  },
  title: {
    // backgroundColor: 'red',
    textAlign: 'center'
  },
  input: {
    width: '100%',
    margin: 10
  }
})

export default LoginPage