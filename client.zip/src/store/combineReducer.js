import { combineReducers } from 'redux';
// Customer Reducer
import userReducer from './user/user.reducer';

export default combineReducers({
  userRoot: userReducer
});
