import { userLogin, getHome } from '../../api/index.js';

export const UserLogin = (userData, history) => {
  return (dispatch) => {
    // console.log(userData)
    userLogin(userData)
      .then((response) => {
        console.log(response.data)
        dispatch({
          type:"USER_LOGIN",
          payload: {
            message: response.data.message,
            path: response.data.path
          }
        });
        localStorage.setItem('isAuth', response.data.isAuth)
        history.push(response.data.path)
      })
  }
};

export const GetHome = (history) => {
  return (dispatch) => {
    getHome()
      .then((response) => {
        console.log(response.data)
        dispatch({
          type:"GET_HOME",
          payload: {
            message: response.data.message,
            path: response.data.path
          }
        });
        history.push(response.data.path)
      })
  }
}