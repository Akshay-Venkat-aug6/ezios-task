const initialState = {
  message: '',
  path: ''
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'USER_LOGIN':
      return {
        message: action.payload.message,
        path: action.payload.path,
      };
    case 'GET_HOME':
      return {
        message: action.payload.message,
        path: action.payload.path,
      };
    default:
      return state;
  }
};

export default userReducer;