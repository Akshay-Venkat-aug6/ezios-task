import { Logger } from "mongodb"

const homeData = async(req, res) => {
  try {
    console.log(req.session.isAuth)
    return res.send({ message: 'Welcome', path: '/' })
  } catch (error) {
    Logger.error(error.message)
  }
};

export {
  homeData
}