import logger from '@config/logger';
import { v4 as uuidv4 } from 'uuid';

// Const User Credentials
const USEREMAIL = "akshay@gmail.com";
const PASSWORD = "Akshay281096";

const userLogin = async(req, res) => {
  try {
    let { username, password } = req.body;
    // console.log(req.body)
    if ( username === USEREMAIL && password === PASSWORD ) {
      let session = req.session;
      session.isAuth = true;
      console.log(req.session.isAuth)
      return res.send({ message: 'Login Successfully!!', path: '/', isAuth: true } )
    }
  } catch (error) {
    logger.error(error.message);
    console.log(error)
  }
};

const userLogout = async(req, res) => {
  try {
    req.session.destroy();
    return res.send({ path: '/logout', status: true })
  } catch (error) {
    logger.error(error.message);
    console.log(error)
  }
};

export {
  userLogin
}