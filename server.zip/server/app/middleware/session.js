const sessionMiddleware = (req, res, next) => {
  console.log('----------')
  console.log(req.session.isAuth)
  if ( req.session.isAuth) {
    next();
  }
  else {
    return res.send({ message: 'Session is Expired', path: '/login' })
  }
  
};

export {
  sessionMiddleware
}