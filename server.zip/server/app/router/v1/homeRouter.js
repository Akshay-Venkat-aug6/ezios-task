import express from 'express';
import { homeData } from '@controller/home.controller';
import { sessionMiddleware } from '../../middleware/session';

const router = express.Router();

router.get('/v1', sessionMiddleware , homeData);

module.exports = router;
