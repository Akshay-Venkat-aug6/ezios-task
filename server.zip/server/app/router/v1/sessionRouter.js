import express from 'express';

const router = express.Router();

router.get('/v1/session', (req, res) => {
  console.log(req.session.isAuth)
});

module.exports = router;