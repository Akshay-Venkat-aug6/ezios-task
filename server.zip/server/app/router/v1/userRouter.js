/*
  created_by: Akshay Venkat<akshay28venkat@gmail.com>
  created_at: 26-07-2021
*/

import express from 'express';
import { userLogin } from '@controller/user.controller';

const router = express.Router();

router.post('/v1/login', userLogin);

module.exports = router;
