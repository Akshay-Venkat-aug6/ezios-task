import mongoose from 'mongoose';
import logger from './logger';

mongoose.connect(
	'mongodb://localhost/ezios_task?readPreference=primary&appname=MongoDB%20Compass&ssl=false',
	{
		promiseLibrary: require('bluebird'),
		useNewUrlParser: true,
		useUnifiedTopology: true,
		useCreateIndex: true,
		useFindAndModify: false,
	})
	.then(async () => {
		console.log('\x1b[32m%s\x1b[0m', '✔ Connection to DB Succesful');
	})
	.catch((err) => logger.error(err.message));