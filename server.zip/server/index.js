import 'module-alias/register';
import express from 'express';
import logger from '@config/logger';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import xss from 'xss-clean';
import helmet from 'helmet';
import mongoSanitizer from 'express-mongo-sanitize';
import compression from 'compression';
import fileUpload from 'express-fileupload';
import path from 'path';
import sessions from 'express-session';
import cors from 'cors';
const MongoDBSession = require('connect-mongodb-session')(sessions)
// DB Config
import '@config/mongodb';
// Custom Module
import userRouter from '@app/router/v1/userRouter.js';
import homeRouter from '@app/router/v1/homeRouter.js';
import sessionRouter from '@app/router/v1/sessionRouter.js';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 10 requests per windowMs
});

const app = express();
app.use(cors())
// fileupload middleware
app.use(fileUpload({
  useTempFiles : true,
  tempFileDir : path.join(__dirname,'tmp'),
}));
// Used to Prevent the DOS attack
app.use(express.json({ limit: '10kb' }));
// Used to prevent the Xss Attack
app.use(xss());
app.use(helmet());
// Preventing Nosql Attack
app.use(mongoSanitizer());

app.use(morgan('tiny', { stream: logger.stream }));
app.use(compression());

const store = new MongoDBSession({
  uri: 'mongodb://localhost/ezios_task?readPreference=primary&appname=MongoDB%20Compass&ssl=false',
  collection: 'mySessions'
})

const auth = (req, res, next) => {
  if (req.session.auth) {
    next();
  }
  
}
// Creating 2 mins from milliseconds
const oneDay = 120000;
// session middleware
app.use(sessions({
  secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
  saveUninitialized: true,
  cookie: { 
    httpOnly: true,
    maxAge: oneDay },
  resave: false,
  store: store
}));

app.use('/api/', limiter, userRouter );
app.use('/api', homeRouter );
// app.use('/api', sessionRouter );

app.listen(3001, () => {
  logger.info(`Server Running On 3000`)
});